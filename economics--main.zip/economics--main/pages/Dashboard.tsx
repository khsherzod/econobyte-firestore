import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { mockDb } from '../services/mockDb';
import { Lesson, Progress } from '../types';
import LessonCard from '../components/ui/LessonCard';
import { Link } from 'react-router-dom';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { Flame, Trophy, BookOpen, Clock } from 'lucide-react';

export default function Dashboard() {
  const { user } = useAuth();
  const [recentLessons, setRecentLessons] = useState<Lesson[]>([]);
  const [progress, setProgress] = useState<Record<string, Progress>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      const allLessons = await mockDb.getLessons();
      const userProgress = mockDb.getProgress();
      
      // Get lessons that are in progress or not started, prioritizing in progress
      const sorted = allLessons.sort((a, b) => {
        const statusA = userProgress[a.id]?.status || 'not-started';
        const statusB = userProgress[b.id]?.status || 'not-started';
        if (statusA === 'in-progress' && statusB !== 'in-progress') return -1;
        if (statusB === 'in-progress' && statusA !== 'in-progress') return 1;
        return a.order - b.order;
      });

      setRecentLessons(sorted.slice(0, 3));
      setProgress(userProgress);
      setLoading(false);
    };
    fetchData();
  }, []);

  if (loading) return <div className="p-8 text-center text-gray-500">Loading your personalized dashboard...</div>;

  const stats = [
    { label: 'Lessons', value: user?.stats.lessonsCompleted || 0, icon: <BookOpen className="text-blue-500" />, bg: 'bg-blue-50' },
    { label: 'Points', value: user?.stats.totalPoints || 0, icon: <Trophy className="text-yellow-500" />, bg: 'bg-yellow-50' },
    { label: 'Streak', value: `${user?.stats.streakDays || 0} Days`, icon: <Flame className="text-orange-500" />, bg: 'bg-orange-50' },
    { label: 'Time', value: '1.2h', icon: <Clock className="text-green-500" />, bg: 'bg-green-50' },
  ];

  const chartData = [
    { name: 'Mon', score: 20 },
    { name: 'Tue', score: 45 },
    { name: 'Wed', score: 30 },
    { name: 'Thu', score: 80 },
    { name: 'Fri', score: user?.stats.totalPoints || 0 }, // Mock dynamic data
    { name: 'Sat', score: 10 },
    { name: 'Sun', score: 0 },
  ];

  return (
    <div className="space-y-8 animate-fade-in">
      <header>
        <h1 className="text-3xl font-bold text-gray-900">Hey,{user?.displayName} its time to learn! </h1> 
        <p className="text-gray-500 mt-2">Ready to level up your economics knowledge today?</p>
      </header>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <div key={i} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex items-center space-x-4">
            <div className={`p-3 rounded-lg ${stat.bg}`}>
              {stat.icon}
            </div>
            <div>
              <p className="text-sm text-gray-500 font-medium">{stat.label}</p>
              <p className="text-xl font-bold text-gray-900">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        {/* Main Content: Next Lessons */}
        <div className="md:col-span-2 space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold text-gray-900">Continue Learning</h2>
            <Link to="/lessons" className="text-primary-600 hover:text-primary-700 text-sm font-medium">View All</Link>
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            {recentLessons.map(lesson => (
              <LessonCard 
                key={lesson.id} 
                lesson={lesson} 
                status={progress[lesson.id]?.status || 'not-started'} 
              />
            ))}
          </div>
        </div>

        {/* Sidebar: Activity Chart */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <h3 className="text-lg font-bold text-gray-900 mb-4">Weekly Activity</h3>
            <div className="h-48 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <XAxis dataKey="name" fontSize={12} tickLine={false} axisLine={false} />
                  <Tooltip 
                    cursor={{fill: '#f3f4f6'}}
                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  />
                  <Bar dataKey="score" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
          
          <div className="bg-gradient-to-r from-purple-500 to-indigo-600 rounded-xl p-6 text-white relative overflow-hidden">
            <div className="relative z-10">
              <h3 className="font-bold text-lg mb-2">Pro Tip 💡</h3>
              <p className="text-purple-100 text-sm">
                Consistent learning is key to understanding compound interest. Come back tomorrow to keep your streak!
              </p>
            </div>
            <div className="absolute top-0 right-0 -mt-4 -mr-4 w-24 h-24 bg-white opacity-10 rounded-full blur-xl"></div>
          </div>
        </div>
      </div>
    </div>
  );
}