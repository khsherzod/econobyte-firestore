import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Check, X, ArrowRight, RotateCcw } from 'lucide-react';
import { MOCK_QUIZZES } from '../constants';
import { mockDb } from '../services/mockDb';
import { useAuth } from '../context/AuthContext';

export default function Quiz() {
  const { lessonId } = useParams<{ lessonId: string }>();
  const navigate = useNavigate();
  const { updateUserStats } = useAuth();
  
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [showResults, setShowResults] = useState(false);
  
  const quiz = lessonId ? MOCK_QUIZZES[lessonId] : null;

  if (!quiz) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-bold text-gray-900">Quiz not found</h2>
        <button onClick={() => navigate('/lessons')} className="mt-4 text-primary-600 hover:underline">Return to lessons</button>
      </div>
    );
  }

  const currentQuestion = quiz.questions[currentQuestionIndex];
  const progressPercentage = ((currentQuestionIndex) / quiz.questions.length) * 100;

  const handleOptionClick = (index: number) => {
    if (isAnswered) return;
    setSelectedOption(index);
  };

  const handleSubmitAnswer = () => {
    if (selectedOption === null) return;
    
    setIsAnswered(true);
    if (selectedOption === currentQuestion.correctAnswerIndex) {
      setScore(prev => prev + 1);
    }
  };

  const handleNext = async () => {
    if (currentQuestionIndex < quiz.questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setSelectedOption(null);
      setIsAnswered(false);
    } else {
      setShowResults(true);
      await saveResults();
    }
  };

  const saveResults = async () => {
    const finalScorePercent = (score + (selectedOption === currentQuestion.correctAnswerIndex ? 1 : 0)) / quiz.questions.length * 100;
    const isPassed = finalScorePercent >= quiz.passingScore;
    
    // Update progress
    await mockDb.saveProgress(quiz.lessonId, {
      status: isPassed ? 'completed' : 'in-progress',
      quizScore: finalScorePercent,
      completedAt: isPassed ? new Date().toISOString() : undefined
    });

    // Update global user stats
    if (isPassed) {
      updateUserStats({
        totalPoints: (mockDb.getUser()?.stats.totalPoints || 0) + 50,
        quizzesTaken: (mockDb.getUser()?.stats.quizzesTaken || 0) + 1
      });
    }
  };

  if (showResults) {
    const finalScore = Math.round((score / quiz.questions.length) * 100);
    const passed = finalScore >= quiz.passingScore;

    return (
      <div className="max-w-xl mx-auto text-center pt-10 animate-fade-in">
        <div className={`w-24 h-24 mx-auto rounded-full flex items-center justify-center mb-6 ${passed ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`}>
          {passed ? <Check size={48} /> : <X size={48} />}
        </div>
        <h2 className="text-3xl font-bold text-gray-900 mb-2">{passed ? 'Quiz Passed!' : 'Keep Practicing'}</h2>
        <p className="text-gray-500 mb-8">You scored {finalScore}%</p>
        
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 mb-8 text-left">
          <h3 className="font-semibold text-gray-900 mb-4">Summary</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Correct Answers</span>
              <span className="font-medium">{score} / {quiz.questions.length}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Points Earned</span>
              <span className="font-medium text-primary-600">+{passed ? 50 : 10} XP</span>
            </div>
          </div>
        </div>

        <div className="flex gap-4 justify-center">
          <button 
            onClick={() => window.location.reload()}
            className="flex items-center px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 font-medium"
          >
            <RotateCcw size={18} className="mr-2" /> Retry
          </button>
          <button 
            onClick={() => navigate('/dashboard')}
            className="flex items-center px-6 py-3 bg-primary-600 text-white rounded-lg hover:bg-primary-700 font-medium"
          >
            Dashboard <ArrowRight size={18} className="ml-2" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      {/* Progress Bar */}
      <div className="mb-8">
        <div className="flex justify-between text-sm font-medium text-gray-500 mb-2">
          <span>Question {currentQuestionIndex + 1} of {quiz.questions.length}</span>
          <span>{Math.round(progressPercentage)}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div className="bg-primary-600 h-2 rounded-full transition-all duration-500" style={{ width: `${progressPercentage}%` }}></div>
        </div>
      </div>

      {/* Question Card */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 sm:p-8">
        <h2 className="text-xl font-bold text-gray-900 mb-6">{currentQuestion.text}</h2>

        <div className="space-y-3">
          {currentQuestion.options.map((option, idx) => {
            let stateClass = "border-gray-200 hover:border-primary-300 hover:bg-gray-50";
            if (isAnswered) {
              if (idx === currentQuestion.correctAnswerIndex) stateClass = "border-green-500 bg-green-50 text-green-700";
              else if (idx === selectedOption) stateClass = "border-red-500 bg-red-50 text-red-700";
              else stateClass = "border-gray-200 opacity-50";
            } else if (selectedOption === idx) {
              stateClass = "border-primary-500 bg-primary-50 ring-1 ring-primary-500";
            }

            return (
              <button
                key={idx}
                onClick={() => handleOptionClick(idx)}
                disabled={isAnswered}
                className={`w-full text-left p-4 rounded-xl border-2 transition-all duration-200 font-medium ${stateClass}`}
              >
                <div className="flex justify-between items-center">
                  <span>{option}</span>
                  {isAnswered && idx === currentQuestion.correctAnswerIndex && <Check size={20} className="text-green-600" />}
                  {isAnswered && idx === selectedOption && idx !== currentQuestion.correctAnswerIndex && <X size={20} className="text-red-600" />}
                </div>
              </button>
            );
          })}
        </div>

        {/* Explanation */}
        {isAnswered && (
          <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-100 text-blue-800 text-sm animate-fade-in">
            <p className="font-bold mb-1">Explanation:</p>
            {currentQuestion.explanation}
          </div>
        )}

        {/* Footer Actions */}
        <div className="mt-8 pt-6 border-t border-gray-100 flex justify-end">
          {!isAnswered ? (
            <button
              onClick={handleSubmitAnswer}
              disabled={selectedOption === null}
              className="px-6 py-2.5 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              Submit Answer
            </button>
          ) : (
            <button
              onClick={handleNext}
              className="px-6 py-2.5 bg-gray-900 text-white rounded-lg font-medium hover:bg-gray-800 flex items-center transition-colors"
            >
              {currentQuestionIndex === quiz.questions.length - 1 ? 'See Results' : 'Next Question'}
              <ArrowRight size={18} className="ml-2" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}