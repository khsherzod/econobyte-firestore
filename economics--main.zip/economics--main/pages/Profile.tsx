import React from 'react';
import { useAuth } from '../context/AuthContext';
import { ACHIEVEMENTS } from '../constants';
import { Settings, LogOut, Medal } from 'lucide-react';

export default function Profile() {
  const { user, logout } = useAuth();

  if (!user) return null;

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      {/* Profile Header */}
      <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 flex flex-col items-center text-center">
        <div className="w-24 h-24 bg-primary-100 rounded-full flex items-center justify-center text-primary-600 text-3xl font-bold mb-4">
          {user.displayName.charAt(0).toUpperCase()}
        </div>
        <h1 className="text-2xl font-bold text-gray-900">{user.displayName}</h1>
        <p className="text-gray-500">{user.email}</p>
        <div className="mt-4 flex gap-4 text-sm font-medium">
          <div className="bg-gray-50 px-4 py-2 rounded-lg">
            <span className="block text-gray-400 text-xs uppercase">Role</span>
            <span className="text-gray-900 capitalize">{user.role}</span>
          </div>
          <div className="bg-gray-50 px-4 py-2 rounded-lg">
             <span className="block text-gray-400 text-xs uppercase">Joined</span>
            <span className="text-gray-900">Oct 2023</span>
          </div>
        </div>
      </div>

      {/* Achievements Section */}
      <div>
        <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
          <Medal className="mr-2 text-yellow-500" /> Achievements
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {ACHIEVEMENTS.map((achievement) => (
            <div key={achievement.id} className={`p-4 rounded-xl border ${achievement.unlocked ? 'bg-white border-yellow-200' : 'bg-gray-50 border-gray-200 opacity-60'}`}>
              <div className="text-2xl mb-2">{achievement.icon}</div>
              <h3 className="font-bold text-gray-900 text-sm">{achievement.title}</h3>
              <p className="text-xs text-gray-500 mt-1">{achievement.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Settings List */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100 flex items-center">
          <Settings size={18} className="mr-2 text-gray-500" />
          <h3 className="font-bold text-gray-900">Preferences</h3>
        </div>
        <div className="divide-y divide-gray-100">
          <div className="px-6 py-4 flex justify-between items-center">
            <div>
              <p className="text-sm font-medium text-gray-900">Email Notifications</p>
              <p className="text-xs text-gray-500">Receive weekly progress reports</p>
            </div>
            <button className="relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 bg-gray-200">
              <span className="translate-x-0 pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out"></span>
            </button>
          </div>
          <div className="px-6 py-4 flex justify-between items-center">
            <div>
              <p className="text-sm font-medium text-gray-900">Dark Mode</p>
              <p className="text-xs text-gray-500">Coming soon in v2.0</p>
            </div>
            <button className="relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out bg-gray-200 opacity-50 cursor-not-allowed">
              <span className="translate-x-0 pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out"></span>
            </button>
          </div>
        </div>
        <div className="px-6 py-4 bg-gray-50 border-t border-gray-100">
          <button 
            onClick={logout}
            className="text-red-600 text-sm font-medium hover:text-red-700 flex items-center"
          >
            <LogOut size={16} className="mr-2" /> Sign Out
          </button>
        </div>
      </div>
    </div>
  );
}