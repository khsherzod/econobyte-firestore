import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, PlayCircle, CheckCircle } from 'lucide-react';
import { mockDb } from '../services/mockDb';
import { MOCK_QUIZZES } from '../constants';
import { Lesson } from '../types';

export default function LessonDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [lesson, setLesson] = useState<Lesson | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      if (!id) return;
      const data = await mockDb.getLessonById(id);
      if (data) {
        setLesson(data);
        // Mark as in progress if not completed
        const currentProgress = mockDb.getProgress()[id];
        if (!currentProgress || currentProgress.status === 'not-started') {
          mockDb.saveProgress(id, { status: 'in-progress' });
        }
      }
      setLoading(false);
    };
    load();
  }, [id]);

  if (loading) return <div className="p-12 flex justify-center"><div className="animate-spin h-8 w-8 border-2 border-primary-500 rounded-full border-t-transparent"></div></div>;
  if (!lesson) return <div className="p-8">Lesson not found</div>;

  const hasQuiz = !!MOCK_QUIZZES[lesson.id];

  return (
    <article className="max-w-3xl mx-auto pb-20">
      <button onClick={() => navigate('/lessons')} className="flex items-center text-gray-500 hover:text-gray-900 mb-6 transition-colors">
        <ArrowLeft size={20} className="mr-2" /> Back to Lessons
      </button>

      <header className="mb-8">
        <div className="flex items-center space-x-2 text-sm text-primary-600 font-medium mb-3">
          <span className="uppercase tracking-wide">{lesson.category}</span>
          <span>•</span>
          <span>{lesson.estimatedMinutes} min read</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-gray-900 leading-tight mb-4">
          {lesson.title}
        </h1>
        <div className="flex flex-wrap gap-2">
          {lesson.tags.map(tag => (
            <span key={tag} className="px-2.5 py-0.5 rounded-full bg-gray-100 text-gray-600 text-xs font-medium">
              #{tag}
            </span>
          ))}
        </div>
      </header>

      <div className="prose prose-lg prose-blue max-w-none text-gray-700 space-y-6">
        {lesson.content.map((paragraph, idx) => {
          // Simple bold formatting parser for MVP
          const parts = paragraph.split(/(\*\*.*?\*\*)/g).map((part, i) => {
             if (part.startsWith('**') && part.endsWith('**')) {
               return <strong key={i} className="text-gray-900 font-bold">{part.slice(2, -2)}</strong>;
             }
             return part;
          });
          return <p key={idx} className="leading-relaxed">{parts}</p>;
        })}
      </div>

      <div className="mt-12 pt-8 border-t border-gray-200">
        <div className="bg-primary-50 rounded-2xl p-8 text-center">
          <h3 className="text-xl font-bold text-gray-900 mb-2">Ready to test your knowledge?</h3>
          <p className="text-gray-600 mb-6">Take a quick quiz to earn points and complete this lesson.</p>
          
          {hasQuiz ? (
            <Link 
              to={`/quiz/${lesson.id}`}
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-full shadow-sm text-white bg-primary-600 hover:bg-primary-700 transition-colors"
            >
              <PlayCircle className="mr-2 -ml-1" size={20} />
              Start Quiz
            </Link>
          ) : (
            <button
              onClick={() => {
                mockDb.saveProgress(lesson.id, { status: 'completed', completedAt: new Date().toISOString() });
                navigate('/dashboard');
              }}
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-full shadow-sm text-white bg-green-600 hover:bg-green-700 transition-colors"
            >
              <CheckCircle className="mr-2 -ml-1" size={20} />
              Mark as Complete
            </button>
          )}
        </div>
      </div>
    </article>
  );
}