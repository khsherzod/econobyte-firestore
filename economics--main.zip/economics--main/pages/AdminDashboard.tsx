import React, { useState } from 'react';
import { Plus, Edit, Trash, BarChart2 } from 'lucide-react';
import { MOCK_LESSONS } from '../constants';
import { Lesson } from '../types';

export default function AdminDashboard() {
  const [lessons, setLessons] = useState<Lesson[]>(MOCK_LESSONS);
  const [showModal, setShowModal] = useState(false);

  // Stats
  const totalViews = 1250;
  const completionRate = "68%";
  
  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure?')) {
      setLessons(prev => prev.filter(l => l.id !== id));
    }
  };

  return (
    <div className="space-y-8">
      <header className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
          <p className="text-gray-500">Manage content and view platform analytics</p>
        </div>
        <button 
          onClick={() => setShowModal(true)}
          className="flex items-center px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors"
        >
          <Plus size={18} className="mr-2" /> New Lesson
        </button>
      </header>

      {/* Analytics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-medium text-gray-500">Total Lessons</h3>
            <span className="p-2 bg-blue-50 text-blue-600 rounded-lg"><BarChart2 size={18} /></span>
          </div>
          <p className="text-3xl font-bold text-gray-900">{lessons.length}</p>
        </div>
        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-medium text-gray-500">Total Views</h3>
            <span className="p-2 bg-green-50 text-green-600 rounded-lg"><BarChart2 size={18} /></span>
          </div>
          <p className="text-3xl font-bold text-gray-900">{totalViews}</p>
        </div>
        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-medium text-gray-500">Avg. Completion</h3>
            <span className="p-2 bg-purple-50 text-purple-600 rounded-lg"><BarChart2 size={18} /></span>
          </div>
          <p className="text-3xl font-bold text-gray-900">{completionRate}</p>
        </div>
      </div>

      {/* Lesson Management Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="font-bold text-gray-900">Published Lessons</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Title</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Difficulty</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {lessons.map((lesson) => (
                <tr key={lesson.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{lesson.title}</div>
                    <div className="text-sm text-gray-500 truncate max-w-xs">{lesson.summary}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                      {lesson.category}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 capitalize">
                    {lesson.difficulty}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button className="text-primary-600 hover:text-primary-900 mr-4"><Edit size={18} /></button>
                    <button onClick={() => handleDelete(lesson.id)} className="text-red-600 hover:text-red-900"><Trash size={18} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Mock Modal (Visual Only for MVP) */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-lg w-full p-6">
            <h2 className="text-xl font-bold mb-4">Create New Lesson</h2>
            <p className="text-gray-500 mb-6">This feature is simulated in the MVP. In production, this would open a rich text editor form.</p>
            <div className="flex justify-end gap-3">
              <button 
                onClick={() => setShowModal(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button 
                onClick={() => {
                  const newLesson: Lesson = {
                    ...MOCK_LESSONS[0],
                    id: Math.random().toString(),
                    title: 'New Mock Lesson',
                    order: lessons.length + 1
                  };
                  setLessons([...lessons, newLesson]);
                  setShowModal(false);
                }}
                className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700"
              >
                Create Mock
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}