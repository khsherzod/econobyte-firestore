import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, Tag, CheckCircle, ArrowRight } from 'lucide-react';
import { Lesson } from '../../types';

interface LessonCardProps {
  lesson: Lesson;
  status: 'not-started' | 'in-progress' | 'completed';
}

export default function LessonCard({ lesson, status }: LessonCardProps) {
  const getStatusColor = () => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800 border-green-200';
      case 'in-progress': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusText = () => {
    switch (status) {
      case 'completed': return 'Completed';
      case 'in-progress': return 'In Progress';
      default: return 'Start Lesson';
    }
  };

  return (
    <div className="group bg-white rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-all duration-200 overflow-hidden flex flex-col h-full">
      <div className="p-6 flex-1 flex flex-col">
        <div className="flex justify-between items-start mb-4">
          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${getStatusColor()}`}>
            {status === 'completed' && <CheckCircle size={12} className="mr-1" />}
            {getStatusText()}
          </span>
          <span className={`text-xs font-medium uppercase tracking-wider px-2 py-0.5 rounded text-gray-500 bg-gray-50`}>
            {lesson.difficulty}
          </span>
        </div>
        
        <h3 className="text-lg font-bold text-gray-900 mb-2 group-hover:text-primary-600 transition-colors">
          {lesson.title}
        </h3>
        
        <p className="text-gray-500 text-sm mb-4 line-clamp-2 flex-1">
          {lesson.summary}
        </p>
        
        <div className="flex items-center text-gray-400 text-xs mb-4 space-x-4">
          <div className="flex items-center">
            <Clock size={14} className="mr-1" />
            {lesson.estimatedMinutes} min read
          </div>
          <div className="flex items-center">
            <Tag size={14} className="mr-1" />
            {lesson.category}
          </div>
        </div>

        <div className="mt-auto">
          <Link 
            to={`/lessons/${lesson.id}`}
            className="w-full inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-lg text-primary-700 bg-primary-50 hover:bg-primary-100 transition-colors"
          >
            {status === 'completed' ? 'Review Lesson' : 'Start Learning'}
            <ArrowRight size={16} className="ml-2 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </div>
    </div>
  );
}