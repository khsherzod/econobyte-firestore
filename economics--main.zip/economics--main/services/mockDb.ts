import { User, Lesson, Progress } from '../types';
import { MOCK_LESSONS } from '../constants';

const KEYS = {
  USER: 'econobyte_user',
  PROGRESS: 'econobyte_progress',
  LESSONS: 'econobyte_lessons' // allowing local edits for admin
};

// Simulate API delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const mockDb = {
  // User Ops
  getUser: (): User | null => {
    const u = localStorage.getItem(KEYS.USER);
    return u ? JSON.parse(u) : null;
  },
  
  saveUser: (user: User) => {
    localStorage.setItem(KEYS.USER, JSON.stringify(user));
  },

  logout: () => {
    localStorage.removeItem(KEYS.USER);
  },

  // Lesson Ops
  getLessons: async (): Promise<Lesson[]> => {
    await delay(300);
    const local = localStorage.getItem(KEYS.LESSONS);
    if (local) return JSON.parse(local);
    // Return default if no local override
    return MOCK_LESSONS;
  },

  getLessonById: async (id: string): Promise<Lesson | undefined> => {
    await delay(200);
    const lessons = await mockDb.getLessons();
    return lessons.find(l => l.id === id);
  },

  // Progress Ops
  getProgress: (): Record<string, Progress> => {
    const p = localStorage.getItem(KEYS.PROGRESS);
    return p ? JSON.parse(p) : {};
  },

  saveProgress: async (lessonId: string, data: Partial<Progress>) => {
    await delay(400); // Simulate network
    const allProgress = mockDb.getProgress();
    const existing = allProgress[lessonId] || { lessonId, status: 'not-started' };
    
    const updated = { ...existing, ...data };
    allProgress[lessonId] = updated;
    
    localStorage.setItem(KEYS.PROGRESS, JSON.stringify(allProgress));
    
    // Update user stats
    const user = mockDb.getUser();
    if (user) {
      const completedCount = Object.values(allProgress).filter(p => p.status === 'completed').length;
      user.stats.lessonsCompleted = completedCount;
      mockDb.saveUser(user);
    }
    
    return updated;
  }
};