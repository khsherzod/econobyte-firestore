import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';
import { mockDb } from '../services/mockDb';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, role?: 'user' | 'admin') => Promise<void>;
  logout: () => void;
  updateUserStats: (stats: Partial<User['stats']>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for persisted session
    const loadUser = async () => {
      const persistedUser = mockDb.getUser();
      if (persistedUser) {
        setUser(persistedUser);
      }
      setLoading(false);
    };
    loadUser();
  }, []);

  const login = async (email: string, role: 'user' | 'admin' = 'user') => {
    setLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const newUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      email,
      displayName: email.split('@')[0],
      role,
      stats: {
        lessonsCompleted: 0,
        quizzesTaken: 0,
        totalPoints: 0,
        streakDays: 1
      }
    };
    
    setUser(newUser);
    mockDb.saveUser(newUser);
    setLoading(false);
  };

  const logout = () => {
    setUser(null);
    mockDb.logout();
  };

  const updateUserStats = (newStats: Partial<User['stats']>) => {
    if (!user) return;
    const updatedUser = { ...user, stats: { ...user.stats, ...newStats } };
    setUser(updatedUser);
    mockDb.saveUser(updatedUser);
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, logout, updateUserStats }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};